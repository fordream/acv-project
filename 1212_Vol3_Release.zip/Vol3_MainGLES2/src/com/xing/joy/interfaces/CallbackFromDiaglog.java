package com.xing.joy.interfaces;

public interface CallbackFromDiaglog {
	public void callback();
}
