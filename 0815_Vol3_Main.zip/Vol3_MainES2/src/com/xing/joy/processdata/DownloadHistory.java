package com.xing.joy.processdata;

import android.content.Context;
import android.content.SharedPreferences;

public class DownloadHistory {
	/** Share preferences store data. */
	protected SharedPreferences shareReportHistory;

	public DownloadHistory(Context context) {
		// init SharePreference for read/save data
		shareReportHistory = context.getSharedPreferences("history_download",
				Context.MODE_PRIVATE);
	}

	public String getStringData(String key) {
		return shareReportHistory.getString(key, "");
	}

	public int getIntData(String key) {
		return shareReportHistory.getInt(key, 0);
	}
}
