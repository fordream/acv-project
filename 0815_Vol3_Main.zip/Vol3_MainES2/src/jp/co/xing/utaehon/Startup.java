package jp.co.xing.utaehon;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import jp.co.xing.utaehon.R;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import com.android.gcm.CommonUtilities;
import com.android.gcm.ServerUtilities;
import com.google.android.gcm.GCMRegistrar;
import com.xing.joy.common.CoreActivity;
import com.xing.joy.download.DigestUtils;
import com.xing.joy.interfaces.IDataActions;

public class Startup extends CoreActivity {

	/** Image splash screen. */
	private ImageView imgSplashScreen, imgGetActionBar;

	/** Runnable waite . */
	private Runnable runnaSplashScreen;
	private AlertDialog alertDialog;
	AsyncTask<Void, Void, Void> mRegisterTask;
	private ProgressDialog regisDialog;

	/** Tag log. */
	private static final String LOG_STARTUP = "LOG_STARTUP";

	@Override
	public void onCreate(Bundle savedInstanceState) {

		// Set control Media Volume
		setVolumeControlStream(AudioManager.STREAM_MUSIC);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.startup);
		imgSplashScreen = (ImageView) findViewById(R.id.flashscreen);
		resizeView(imgSplashScreen, 0, 0, 0, 0);
		imgGetActionBar = (ImageView) findViewById(R.id.getActionBar);
		resizeView(imgGetActionBar, 0, 0, 0, 0);
		imgGetActionBar.setBackgroundResource(0);

		// AutoCreateShortCut
		autoCreateShortCut();
	}

	public void register() {
		// Make sure the device has the proper dependencies.
		GCMRegistrar.checkDevice(this);
		// Make sure the manifest was properly set - comment out this line
		// while developing the app, then uncomment it when it's ready.
		GCMRegistrar.checkManifest(this);
		final String regId = GCMRegistrar.getRegistrationId(this);
		if (regId.equals("")) {
			// Automatically registers application on startup.
			GCMRegistrar.register(this, CommonUtilities.SENDER_ID);
			regisDialog = new ProgressDialog(this);
			regisDialog.setMessage("登録中・・・");
			regisDialog.show();
			imgSplashScreen.postDelayed(new Runnable() {

				@Override
				public void run() {
					if (regisDialog != null) {
						regisDialog.dismiss();
					}
					startNextActiviy();
				}
			}, 3000);
		} else {
			// Device is already registered on GCM, needs to check if it is
			// registered on our server as well.
			if (GCMRegistrar.isRegisteredOnServer(this)) {
				// Skips registration.
				// Log.d("TEST", getString(R.string.already_registered));
				startNextActiviy();
			} else {
				// Try to register again, but not in the UI thread.
				// It's also necessary to cancel the thread onDestroy(),
				// hence the use of AsyncTask instead of a raw thread.
				final Context context = this;
				mRegisterTask = new AsyncTask<Void, Void, Void>() {

					@Override
					protected Void doInBackground(Void... params) {
						boolean registered = ServerUtilities.register(context,
								regId);
						// At this point all attempts to register with the app
						// server failed, so we need to unregister the device
						// from GCM - the app will try to register again when
						// it is restarted. Note that GCM will send an
						// unregistered callback upon completion, but
						// GCMIntentService.onUnregistered() will ignore it.
						if (!registered) {
							GCMRegistrar.unregister(context);
						}
						return null;
					}

					@Override
					protected void onPostExecute(Void result) {
						mRegisterTask = null;
						startNextActiviy();
					}

				};
				mRegisterTask.execute(null, null, null);
			}
		}
	}

	public void confirmRegisterWithC2DM() {
		alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setMessage(getString(R.string.allow_push));
		alertDialog.setCancelable(false);
		alertDialog.setCanceledOnTouchOutside(false);
		alertDialog.setButton2(this.getString(R.string.btn_no),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						appData.setStringData("AllowReceivePush", "no");
						alertDialog.dismiss();
						GCMRegistrar.unregister(Startup.this);
						startNextActiviy();
						return;
					}
				});
		alertDialog.setButton(this.getString(R.string.btn_yes),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						appData.setStringData("AllowReceivePush", "yes");
						register();
						alertDialog.dismiss();
						return;
					}
				});
		alertDialog.show();
	}

	private void autoCreateShortCut() {
		if (!appData.getBoolData(IDataActions.IS_SHORTCUT)) {
			// Create Shortcut
			final String title = getResources().getString(R.string.app_name);
			final int icon = R.drawable.icon;
			final Class<?> cls = Startup.class;

			final Intent shortcutIntent = new Intent();
			shortcutIntent.setClass(this, cls);
			shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

			final Intent putShortCutIntent = new Intent();
			putShortCutIntent.putExtra("duplicate", false);
			putShortCutIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT,
					shortcutIntent);
			putShortCutIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, title);
			putShortCutIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
					Intent.ShortcutIconResource.fromContext(this, icon));
			putShortCutIntent
					.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
			sendBroadcast(putShortCutIntent);
			appData.setBoolData(IDataActions.IS_SHORTCUT, true);
		}
	}

	@Override
	protected void onResume() {
		if (imgSplashScreen != null) {
			imgSplashScreen.postDelayed(runnaSplashScreen = new Runnable() {

				@Override
				public void run() {
					if (appData.getStringData("AllowReceivePush")
							.equalsIgnoreCase("")) {
						confirmRegisterWithC2DM();
					} else {
						if (appData.getStringData("AllowReceivePush")
								.equalsIgnoreCase("yes")) {
							register();
						} else {
							startNextActiviy();
						}
					}
				}
			}, 1500);
		}
		super.onResume();
	}

	@Override
	public void showPushNotification() {
		// Nothing
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		if (appData.getIntData(IDataActions.HEIGHT_BAR) == 0) {
			appData.setIntData(IDataActions.HEIGHT_BAR,
					calResize.getHeight() - imgGetActionBar.getHeight() - 2
							* calResize.getHemBlackHeight());
		}
	}

	private void startNextActiviy() {
		// Set intent
		Intent intent = new Intent(Intent.ACTION_DEFAULT);
		try {
			intent.setComponent(new ComponentName(getPackageName(), appData
					.getStringData(IDataActions.CLASS_NAME)));
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			finish();
		} catch (Exception e) {
			intent = new Intent(Startup.this, com.xing.joy.others.Top.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			this.startActivity(intent);
			finish();
		}
	}

	@Override
	protected void onPause() {
		if (imgSplashScreen != null) {
			imgSplashScreen.removeCallbacks(runnaSplashScreen);
			imgSplashScreen.setBackgroundResource(0);
			imgSplashScreen = null;
		}
		runnaSplashScreen = null;
		Log.d(LOG_STARTUP, "On Pause");
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		GCMRegistrar.onDestroy(this);
		super.onDestroy();
	}

	@Override
	public void setBaseApplicationData() {
		return;
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
	}

	/**
	 * Check file unzip success or file exist. Return true if file Unzip
	 * Success. Return false if file on Exist or Unzip failed.
	 * 
	 * @return boolean
	 * */
	public boolean checkFileReady(File file) {
		boolean result = true;
		if (!file.exists()) {
			result = false;
		} else {
			try {
				InputStream input = new FileInputStream(file);
				String md5Font = DigestUtils.md5Hex(input);
				if (!md5Font.equalsIgnoreCase(getString(R.string.cs_font)
						.trim())) {
					result = false;
					file.delete();
				}
			} catch (IOException e) {
				result = false;
			}
		}
		return result;
	}
}
