package com.xing.joy.others;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import jp.co.xing.utaehon.R;
import jp.co.xing.utaehon03.util.CommonUtils;
import jp.co.xing.utaehon03.util.MemoryUtils;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.android.vending.billing.BillingService;
import com.android.vending.billing.BillingService.RequestPurchase;
import com.android.vending.billing.BillingService.RestoreTransactions;
import com.android.vending.billing.Consts;
import com.android.vending.billing.Consts.PurchaseState;
import com.android.vending.billing.Consts.ResponseCode;
import com.android.vending.billing.PurchaseObserver;
import com.android.vending.billing.ResponseHandler;
import com.xing.joy.common.CoreActivity;
import com.xing.joy.common.DownloadProgessBar;
import com.xing.joy.common.HorizontalPager;
import com.xing.joy.common.HorizontalPager.OnScrollListener;
import com.xing.joy.common.PackageSongs;
import com.xing.joy.common.PackageXMLHandler;
import com.xing.joy.common.PackagesList;
import com.xing.joy.processdata.Download;
import com.xing.joy.processdata.FilesModel;
import com.xing.joy.processdata.ReportHistory;
import com.xing.joy.processdata.Unzip;

/**
 * This activity for display purchase screen.
 * */
public class Buy extends CoreActivity implements OnTouchListener,
		OnClickListener {

	public static String BACK_SCREEN = "";

	/** Tag log name. */
	private static final String TAG = Buy.class.getSimpleName();

	/** View id=CONST_ID+packageID. */
	private static final int CONST_ID = 1500;

	/** Intent for start activity. */
	private Intent intent;

	/** Package list. */
	private PackagesList packagesList = null;

	/** List all packages that show in Buy Screen. */
	private List<PackageSongs> packageSongs = new ArrayList<PackageSongs>();

	/** List all songs in version 1. */
	private List<PackageSongs> singleV1Songs = new ArrayList<PackageSongs>();

	/** List all songs in version 2. */
	private List<PackageSongs> singleV2Songs = new ArrayList<PackageSongs>();

	/** List all songs in version 1. */
	private List<PackageSongs> singleV1_2Songs = new ArrayList<PackageSongs>();

	/** Layout of buy. */
	private RelativeLayout rlBuy;

	/** Lay out of one page. */
	private RelativeLayout[] pageLayout;

	/** Scroll pager. */
	private HorizontalPager realViewSwitcher;

	/** Position of 6 songs in one page. */
	private int[][] coor = { { 250, 30 }, { 580, 30 }, { 250, 230 },
			{ 580, 230 }, { 250, 430 }, { 580, 430 } };

	/** Image Slide. */
	private ImageView imgSlide;

	/** Image switch to list vol1&2. */
	private ImageView imgSwitch;

	/** Image vol1 button. */
	private ImageView imgVol1;

	/** Image vol2 button. */
	private ImageView imgVol2;

	/** Image information. */
	private ImageView imgInfo;

	/** Image cancel information. */
	private ImageView imgCancelInfo;

	/** Temporary ImageView storing the Icon of Package which is clicked. */
	private static ImageView purchasedImage;

	/** Image for buy button. */
	private ImageView imgBuy;

	/** Image for download button. */
	private ImageView imgDownload;

	/** Image for button displayed when Download OK. */
	private ImageView imgOK;

	/** Unknown purpose. */
	private AnimationDrawable aniDrawSwitchSingle;

	/** Total of all pages in scroll. */
	private int totalPage = 0;

	/**
	 * Mode display = 0: show package songs Mode display = 1: show single songs
	 */
	private int modeDisplay = 0;

	/**
	 * When modeDisplay = 1 Vol display = 1: show single songs vol 1 Vol display
	 * = 2: show single songs vol 2
	 */
	private static int volDisplay = 0;

	/** Dialog show when error occurred. */
	private ProgressDialog progressDialog;

	/**
	 * The SharedPreferences key for recording whether we initialized the
	 * database. If false, then we perform a RestoreTransactions request to get
	 * all the purchases for this user.
	 */
	private static final String FINISH_RESTORE = "finishRestore";

	/** Store flag about billing support result. */
	private static final String BILLING_SUPPORT = "billing_support";

	/** Purchase package when user select. */
	private String purchasedPackage = null;

	/** File path saved. */
	// private String pathSave = null;

	/** Observer to update UI. */
	private static BillingObserver mBillingObserver;

	/** Handler to post action to UI thread. */
	private Handler mHandler;

	/** Billing service to send request to Market. */
	private BillingService mBillingService;

	/** Dialog type 1. */
	private static final int DIALOG_CANNOT_CONNECT_ID = 1;

	/** Dialog type 2. */
	private static final int DIALOG_BILLING_NOT_SUPPORTED_ID = 2;

	/** Shared preference file name to store purchase result. */
	private static final String PURCHASED_DB = "purchased_db";

	/** Share Preference for purchase_db. */
	private SharedPreferences prefs = null;

	/** Editor for edit data. */
	private SharedPreferences.Editor edit = null;

	/** Flag detect SDCard Exist. */
	private boolean isSDCardExisted = false;
	/**
	 * Flag detect application run in first time, by this flag to prevent
	 * download when restore transaction is finish.
	 */
	private boolean isFirstRun = false, isAllowDownload = false;

	/** Download ProgressBar X close button. */
	private ImageView mProgressCloseX;

	/** Download ProgressBar Deer. */
	private ImageView mProgressDeer;

	/** Download ProgressBar background whole. */
	private ImageView mProgressBgr;

	/** Download ProgressBar background. */
	private ImageView mProgressKage;

	/** Download ProgressBar. */
	private ImageView mProgressBar;

	/** Text on Download ProgressBar */
	private ImageView mProgressText;

	private TextView page;

	private DownloadProgessBar downloadBar;

	private DownloadSongPackage dlPackage;

	private SongPackageUnzip spUnzip;

	private Handler waitingDownload;
	private Runnable runDownload;

	/**
	 * A {@link PurchaseObserver} is used to get call backs when Android Market
	 * sends messages to this application so that we can update the UI.
	 */
	private class BillingObserver extends PurchaseObserver {

		/**
		 * Default constructor.
		 **/
		public BillingObserver(Handler handler) {
			super(Buy.this, handler);
		}

		@Override
		public void onBillingSupported(boolean supported) {
			if (Consts.DEBUG) {
				Log.i(TAG, "supported: " + supported);
			}
			if (supported) {
				restoreTransactions();
				enableWidgets();

				// Update BillingSupport Flag
				edit.putBoolean(BILLING_SUPPORT, true);
				edit.commit();
			} else {
				edit.putBoolean(BILLING_SUPPORT, false);
				edit.commit();
				showDialog(DIALOG_BILLING_NOT_SUPPORTED_ID);
			}
		}

		@Override
		public void onPurchaseStateChange(PurchaseState purchaseState,
				String itemId, long purchaseTime, String developerPayload) {
			try {
				if (purchaseState == PurchaseState.PURCHASED) {
					if (Consts.DEBUG) {
						Log.i(TAG, "onPurchaseStateChange() itemId: " + itemId
								+ ":" + purchaseState);
					}

					// Execute get song package and UNZIP when purchase success.
					/**
					 * Because when restore or purchase success, function
					 * onPurchaseStateChage is call, we not allow download
					 * package if this function call after restore transaction.
					 */
					if (!isFirstRun) {
						if (isAllowDownload) {
							waitingDownload.removeCallbacks(runDownload);
							dlPackage = (DownloadSongPackage) new DownloadSongPackage(
									Buy.this).execute();
							Log.d(TAG, "download song.");
						} else {

						}
					} else {
						Log.d(TAG, "not download song when first run.");
					}
				} else {
					imgBuy.setEnabled(true);
					imgBuy.setAlpha(255);
					imgCancelInfo.setEnabled(true);
					imgCancelInfo.setAlpha(255);
					mProgressCloseX.setEnabled(true);
					mProgressCloseX.setAlpha(255);
					if (waitingDownload != null && runDownload != null) {
						waitingDownload.removeCallbacks(runDownload);
					}
					isTouch = true;
					isAllowDownload = false;
				}
			} catch (Exception e) {
			}
		}

		@Override
		public void onRequestPurchaseResponse(RequestPurchase request,
				ResponseCode responseCode) {
			if (Consts.DEBUG) {
				Log.d(TAG, request.mProductId + ": " + responseCode);
			}
			if (responseCode == ResponseCode.RESULT_OK) {
				if (Consts.DEBUG) {
					Log.i(TAG, "purchase was successfully sent to server");
				}
			} else {
				if (responseCode == ResponseCode.RESULT_USER_CANCELED) {
					if (Consts.DEBUG) {
						Log.e(TAG, "user canceled purchase");
					}
				} else if (responseCode == ResponseCode.RESULT_ERROR) {
					if (Consts.DEBUG) {
						Log.e(TAG, "purchase error: " + responseCode);
						// showDialog(DIALOG_BILLING_NOT_SUPPORTED_ID);
					}
				} else {
					if (Consts.DEBUG) {
						Log.e(TAG, "purchase failed: " + responseCode);
					}
				}
				// Re-enable Buy and Cancel button if purchase failed.
				imgBuy.setEnabled(true);
				imgBuy.setAlpha(255);
				imgCancelInfo.setEnabled(true);
				imgCancelInfo.setAlpha(255);
				mProgressCloseX.setEnabled(true);
				mProgressCloseX.setAlpha(255);
				isTouch = true;
				isAllowDownload = false;
				if (waitingDownload != null && runDownload != null) {
					waitingDownload.removeCallbacks(runDownload);
				}
			}
		}

		@Override
		public void onRestoreTransactionsResponse(RestoreTransactions request,
				ResponseCode responseCode) {

			// In case restore transaction error. Function
			// onpurchaseStateChanged not call.
			if (progressDialog != null) {
				progressDialog.dismiss();
				Log.d(TAG, "Dismiss progressDialog");
			}
			if (responseCode == ResponseCode.RESULT_OK) {
				if (Consts.DEBUG) {
					Log.d(TAG, "completed RestoreTransactions request");
				}

				// Update the shared preferences so that we don't perform
				// a RestoreTransactions again.
				edit.putBoolean(FINISH_RESTORE, true);
				edit.commit();
			} else {
				if (Consts.DEBUG) {
					Log.d(TAG, "RestoreTransactions error: " + responseCode);
				}
			}
		}
	}

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {

		// Check SDCARD Exist.
		MemoryUtils sdc = new MemoryUtils(this);
		isSDCardExisted = (sdc.checkSDFreeMB() == 0) ? false : true;
		if (!isSDCardExisted) {
			Toast.makeText(getApplicationContext(),
					getString(R.string.no_sdcard), Toast.LENGTH_LONG).show();
		}

		// Initial shared preferences.
		prefs = getApplication().getSharedPreferences(PURCHASED_DB,
				MODE_PRIVATE);
		edit = prefs.edit();

		// Create hem image.
		setContentView(R.layout.buy);
		super.onCreate(savedInstanceState);
		createHemImage(R.id.buy_display);

		imgSlide = (ImageView) findViewById(R.id.slider);
		resizeView(imgSlide, 0, 0, 0, 0);
		imgSwitch = (ImageView) findViewById(R.id.tankyoku);
		resizeView(imgSwitch, 0, 568, 0, 0);
		imgSwitch.setOnTouchListener(this);
		imgSwitch.setBackgroundResource(R.anim.single_click_change);
		aniDrawSwitchSingle = (AnimationDrawable) imgSwitch.getBackground();
		imgVol1 = (ImageView) findViewById(R.id.vol1);
		resizeView(imgVol1, 0, 290, 0, 0);
		imgVol1.setOnTouchListener(this);
		imgVol2 = (ImageView) findViewById(R.id.vol2);
		resizeView(imgVol2, 0, 420, 0, 0);
		imgVol2.setOnTouchListener(this);
		rlBuy = (RelativeLayout) findViewById(R.id.buy_display_1);
		resizeView(rlBuy, 0, 0, 0, 0);
		imgInfo = (ImageView) findViewById(R.id.info);
		resizeView(imgInfo, 0, 0, 0, 0);
		// imgInfo.setOnTouchListener(this);
		imgBuy = (ImageView) findViewById(R.id.ok_info);
		resizeView(imgBuy, 485, 510, 0, 0);
		imgDownload = (ImageView) findViewById(R.id.dl_btn);
		resizeView(imgDownload, 485, 510, 0, 0);
		imgOK = (ImageView) findViewById(R.id.ok_download);
		resizeView(imgOK, 388, 510, 0, 0);
		imgCancelInfo = (ImageView) findViewById(R.id.cancel_info);
		resizeView(imgCancelInfo, 285, 510, 0, 0);
		mProgressCloseX = (ImageView) findViewById(R.id.close_x_btn);
		resizeView(mProgressCloseX, 898, 0, 0, 0);
		imgBuy.setOnClickListener(this);
		imgDownload.setOnClickListener(this);
		imgCancelInfo.setOnClickListener(this);
		imgOK.setOnClickListener(this);
		mProgressCloseX.setOnClickListener(this);

		// Initialize In-app Billing.
		mHandler = new Handler();
		mBillingObserver = new BillingObserver(mHandler);
		mBillingService = new BillingService();
		mBillingService.setContext(this);

		/**
		 * If not purchased, setup the Billing widgets, then check if Billing is
		 * supported. Enable click buy button.
		 */
		// Check if billing is supported.
		ResponseHandler.register(mBillingObserver);
		imgBuy.setEnabled(false);
		if (!mBillingService.checkBillingSupported()) {
			showDialog(DIALOG_CANNOT_CONNECT_ID);
		}

		addBackButton(R.id.buy_display);
		// Create the view switcher
		realViewSwitcher = (HorizontalPager) findViewById(R.id.horizontal_pager);
		realViewSwitcher.addOnScrollListener(new OnScrollListener() {

			@Override
			public void onViewScrollFinished(final int screen) {
				page.setText((screen + 1) + "/" + totalPage + " "
						+ getString(R.string.page));
				if (screen >= totalPage) {
					new Handler().postDelayed(new Runnable() {

						@Override
						public void run() {
							realViewSwitcher.setCurrentScreen(totalPage - 1,
									false);
							page.setText(screen + "/" + totalPage + " "
									+ getString(R.string.page));
						}
					}, 100);

				}
			}

			@Override
			public void onScroll(int scrollX) {
			}
		});
		totalPage = 1;
		parsePackageInfoXML();
		// calculate number pages and create page
		calculateTotalPage();
		createPages();
		if (modeDisplay == 0) {
			setBackgroundForPackagesSong();
			imgVol1.setEnabled(false);
			imgVol2.setEnabled(false);
		} else {
			if (volDisplay == 1) {
				setBackgroundForSingleV1Song();
			} else {
				setBackgroundForSingleV2Song();
			}
		}

		page = (TextView) findViewById(R.id.help_text);
		resizeView(page, 505, 600, 0, 0);

		Typeface font = Typeface.createFromFile(this.getFilesDir().toString()
				+ "/a_otf_jun501pro_bold.otf");
		page.setTextColor(Color.rgb(102, 51, 0));
		page.setTypeface(font);
	}

	@Override
	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume");
		if (mBillingObserver == null) {
			mBillingObserver = new BillingObserver(mHandler);
			ResponseHandler.register(mBillingObserver);
		}
		if (purchasedPackage != null && isAllowDownload) {

			waitingDownload = new Handler();
			waitingDownload.postDelayed(runDownload = new Runnable() {

				@Override
				public void run() {
					try {
						CommonUtils.popupAlert(Buy.this,
								getString(R.string.billing_not_response));
						imgBuy.setEnabled(true);
						imgBuy.setAlpha(255);
						imgCancelInfo.setEnabled(true);
						imgCancelInfo.setAlpha(255);
						mProgressCloseX.setEnabled(true);
						mProgressCloseX.setAlpha(255);
						isTouch = true;
						isAllowDownload = false;
					} catch (Exception e) {
					}
				}
			}, 10000);
		}
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		if (hasFocus) {
			aniDrawSwitchSingle.start();
			if (page != null) {
				int sizePage = page.getHeight() / 2;
				if (sizePage < 20) {
					sizePage = 20;
				}
				if (sizePage > 40) {
					sizePage = 40;
				}
				page.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePage);
			}
		}
	}

	// Process Touch Event.
	public boolean onTouch(View view, MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN && isTouch) {
			switch (view.getId()) {
			case R.id.tankyoku:
				clearAllPages();
				if (modeDisplay == 1) {
					modeDisplay = 0;
					// recalculate number pages and recreate page.
					imgVol1.setBackgroundResource(0);
					imgVol2.setBackgroundResource(0);
					imgVol1.setEnabled(false);
					imgVol2.setEnabled(false);
					imgSlide.setBackgroundResource(R.drawable.sideber_cat_iphone);
					calculateTotalPage();
					createPages();
					setBackgroundForPackagesSong();
					realViewSwitcher.setCurrentScreen(0, false);
					imgSwitch.setBackgroundResource(R.anim.single_click_change);
					aniDrawSwitchSingle = (AnimationDrawable) imgSwitch
							.getBackground();
					aniDrawSwitchSingle.start();
				} else {
					modeDisplay = 1;
					switch (volDisplay) {
					case 0:
						// recalculate number pages and recreate page.
						imgVol1.setBackgroundResource(R.drawable.vol1off_iphone);
						imgVol2.setBackgroundResource(R.drawable.vol2off_iphone);
						imgSlide.setBackgroundResource(R.drawable.sideber_iphone);
						calculateTotalPage();
						createPages();
						setBackgroundForSingleV1_2Song();
						break;
					case 1:
						// recalculate number pages and recreate page.
						imgVol1.setBackgroundResource(R.drawable.vol1on_iphone);
						imgVol2.setBackgroundResource(R.drawable.vol2off_iphone);
						imgSlide.setBackgroundResource(R.drawable.sideber_iphone);
						calculateTotalPage();
						createPages();
						setBackgroundForSingleV1Song();
						break;
					case 2:
						// recalculate number pages and recreate page.
						imgVol1.setBackgroundResource(R.drawable.vol1off_iphone);
						imgVol2.setBackgroundResource(R.drawable.vol2on_iphone);
						imgSlide.setBackgroundResource(R.drawable.sideber_iphone);
						calculateTotalPage();
						createPages();
						setBackgroundForSingleV2Song();
						break;
					}
					realViewSwitcher.setCurrentScreen(0, false);
					imgVol1.setEnabled(true);
					imgVol2.setEnabled(true);
					aniDrawSwitchSingle.stop();
					imgSwitch.setBackgroundResource(R.drawable.buy_pack_iphone);
				}
				break;

			case R.id.vol1:
				volDisplay = 1;
				clearAllPages();

				// recalculate number pages and recreate page.
				imgVol1.setBackgroundResource(R.drawable.vol1on_iphone);
				imgVol2.setBackgroundResource(R.drawable.vol2off_iphone);
				imgSlide.setBackgroundResource(R.drawable.sideber_iphone);
				calculateTotalPage();
				createPages();
				setBackgroundForSingleV1Song();
				realViewSwitcher.setCurrentScreen(0, false);
				break;

			case R.id.vol2:
				volDisplay = 2;
				clearAllPages();

				// recalculate number pages and recreate page.
				imgVol1.setBackgroundResource(R.drawable.vol1off_iphone);
				imgVol2.setBackgroundResource(R.drawable.vol2on_iphone);
				imgSlide.setBackgroundResource(R.drawable.sideber_iphone);
				calculateTotalPage();
				createPages();
				setBackgroundForSingleV2Song();
				realViewSwitcher.setCurrentScreen(0, false);
				break;

			default:
				break;
			}
		}
		return true;
	}

	@Override
	public void onClick(View view) {
		if (!isTouch) {
			return;
		}
		page.setVisibility(View.INVISIBLE);
		boolean isPurchased = false;
		for (Iterator<PackageSongs> iterator = packageSongs.iterator(); iterator
				.hasNext();) {
			PackageSongs ps = (PackageSongs) iterator.next();
			if (view.getId() == ps.getPackageID() + CONST_ID) {
				isPurchased = processPackagePurchased(ps);
				break;
			}
		}
		for (Iterator<PackageSongs> iterator = singleV1Songs.iterator(); iterator
				.hasNext();) {
			PackageSongs ps = (PackageSongs) iterator.next();
			if (view.getId() == ps.getPackageID() + CONST_ID) {

				// Get package name for purchase if is click to Vol1 songs.
				isPurchased = processPackagePurchased(ps);
				break;
			}
		}
		for (Iterator<PackageSongs> iterator = singleV2Songs.iterator(); iterator
				.hasNext();) {
			PackageSongs ps = (PackageSongs) iterator.next();
			if (view.getId() == ps.getPackageID() + CONST_ID) {

				// Get package name for purchase if is click to Vol2 songs.
				isPurchased = processPackagePurchased(ps);
				break;
			}
		}
		if (view == imgCancelInfo || view == mProgressCloseX) {
			imgInfo.setOnTouchListener(null);
			imgCancelInfo.setImageResource(0);
			imgBuy.setImageResource(0);
			imgDownload.setVisibility(View.GONE);
			mProgressCloseX.setImageResource(0);
			setNullViewDrawable(imgInfo);
			imgOK.setVisibility(View.GONE);
			imgBack.setVisibility(View.VISIBLE);
			imgBuy.setEnabled(false);
			purchasedPackage = null;
			page.setVisibility(View.VISIBLE);
		}
		if (view == imgOK) {
			refreshDisplay();
			imgInfo.setOnTouchListener(null);
			imgOK.setVisibility(View.GONE);
			imgBuy.setImageResource(0);
			imgDownload.setVisibility(View.GONE);
			mProgressCloseX.setImageResource(0);
			setNullViewDrawable(imgInfo);
			imgBack.setVisibility(View.VISIBLE);
			page.setVisibility(View.VISIBLE);
			imgBuy.setEnabled(false);
			purchasedPackage = null;
		}
		if (view == imgBuy) {
			if (!isPurchased) {
				Log.d(TAG, "Clicked Buy Button for buy:" + purchasedPackage);
				// Buy Song.

				// If not purchased, start in-app billing process
				mBillingService.requestPurchase(purchasedPackage, null);
			} else {
				Log.d(TAG, "Already bought song");
			}
			// Disable Buy and Cancel button after Buy button is clicked.
			imgBuy.setEnabled(false);
			imgBuy.setAlpha(50);
			imgCancelInfo.setEnabled(false);
			imgCancelInfo.setAlpha(50);
			mProgressCloseX.setEnabled(false);
			mProgressCloseX.setAlpha(50);
			isAllowDownload = true;
			isTouch = false;
		}
		if (view == imgDownload) {
			Log.d(TAG, "Already bought song, redownloading:" + purchasedPackage);
			// Re down load if package is purchased and user removed
			// or down load failed.
			dlPackage = (DownloadSongPackage) new DownloadSongPackage(Buy.this)
					.execute();
		}
	}

	private void refreshDisplay() {
		clearAllPages();
		calculateTotalPage();
		createPages();
		if (modeDisplay == 0) {
			setBackgroundForPackagesSong();
		} else {
			switch (volDisplay) {
			case 0:
				setBackgroundForSingleV1_2Song();
				break;
			case 1:
				setBackgroundForSingleV1Song();
				break;
			case 2:
				setBackgroundForSingleV2Song();
				break;
			}
		}
	}

	/**
	 * This method used for calculate number of pages loaded.
	 * */
	private void calculateTotalPage() {

		// calculate number pages.
		if (modeDisplay == 0) {
			totalPage = PackageSongs.packageSongs / 6;
			if (PackageSongs.packageSongs % 6 > 0) {
				totalPage += 1;
			}
		} else {
			switch (volDisplay) {
			case 0:
				totalPage = PackageSongs.singleV1_2Songs / 6;
				if (PackageSongs.singleV1_2Songs % 6 > 0) {
					totalPage += 1;
				}
				break;
			case 1:
				totalPage = PackageSongs.singleV1Songs / 6;
				if (PackageSongs.singleV1Songs % 6 > 0) {
					totalPage += 1;
				}
				break;
			case 2:
				totalPage = PackageSongs.singleV2Songs / 6;
				if (PackageSongs.singleV2Songs % 6 > 0) {
					totalPage += 1;
				}
				break;

			default:
				break;
			}
		}
		if (totalPage == 0) {
			totalPage = 1;
		}
	}

	/**
	 * This method used for initial one page of scroll page.
	 * */
	private void createPages() {
		pageLayout = new RelativeLayout[totalPage];
		if (realViewSwitcher != null) {
			realViewSwitcher.removeAllViews();
		}
		// Create & set background for layout of each page.
		for (int i = 0; i < pageLayout.length; i++) {
			pageLayout[i] = new RelativeLayout(this);
			LayoutParams param = new LayoutParams(Math.round(960 * calResize
					.getRatioResizeWidth()), Math.round(640 * calResize
					.getRatioResizeHeight()));
			param.setMargins(Math.round(0 * calResize.getRatioResizeWidth()),
					Math.round(0 * calResize.getRatioResizeHeight()), 0, 0);
			pageLayout[i].setLayoutParams(param);
			if (realViewSwitcher != null) {
				realViewSwitcher.addView(pageLayout[i]);
			}

			ImageView tmp = new ImageView(this);
			tmp.setLayoutParams(param);
			tmp.setBackgroundResource(R.drawable.a1_18_iphone_buy_haikei);
			pageLayout[i].addView(tmp);
		}
	}

	/**
	 * This method used for clear page.
	 * */
	private void clearAllPages() {

		for (Iterator<PackageSongs> iterator = packageSongs.iterator(); iterator
				.hasNext();) {
			PackageSongs ps = (PackageSongs) iterator.next();
			setNullViewDrawable(ps.getImage());
			ps = null;
		}

		for (Iterator<PackageSongs> iterator = singleV1Songs.iterator(); iterator
				.hasNext();) {
			PackageSongs ps = (PackageSongs) iterator.next();
			setNullViewDrawable(ps.getImage());
			ps = null;
		}

		for (Iterator<PackageSongs> iterator = singleV2Songs.iterator(); iterator
				.hasNext();) {
			PackageSongs ps = (PackageSongs) iterator.next();
			setNullViewDrawable(ps.getImage());
			ps = null;
		}

		for (int i = 0; i < pageLayout.length; i++) {
			pageLayout[i].removeAllViews();
			realViewSwitcher.removeView(pageLayout[i]);
		}
	}

	/**
	 * This method used for set background for package songs.
	 * */
	private void setBackgroundForPackagesSong() {

		if (modeDisplay == 0 && packageSongs.size() > 0) {
			int countPackage = 0;

			// browse to each page.
			for (int i = 0; i < totalPage; i++) {
				for (int j = 0; j < 6; j++) {
					// initial image.
					Bitmap bmImg = BitmapFactory.decodeFile(memory
							.getPathFileInternalMemory()
							+ "img_buy/"
							+ packageSongs.get(countPackage).getIconImage());
					Drawable d = new BitmapDrawable(bmImg);
					ImageView tmp = new ImageView(this);
					tmp.setBackgroundDrawable(d);
					if (isAppInstalled(memory.getPathFileExternalMemory()
							+ packageSongs.get(countPackage).getPackageName(),
							packageSongs.get(countPackage).getPackageName())) {
						tmp.getBackground().setAlpha(100);
					}
					if (isAppRelationInstalled(packageSongs.get(countPackage)
							.getPackageName(), packageSongs.get(countPackage)
							.getPackagesRelation())) {
						tmp.getBackground().setAlpha(100);
					}
					pageLayout[i].addView(tmp);
					tmp.setId(CONST_ID
							+ packageSongs.get(countPackage).getPackageID());
					RelativeLayout.LayoutParams prView = new RelativeLayout.LayoutParams(
							Math.round(317 * calResize.getRatioResizeWidth()),
							Math.round(166 * calResize.getRatioResizeHeight()));
					prView.setMargins(
							Math.round(coor[j][0]
									* calResize.getRatioResizeWidth()),
							Math.round(coor[j][1]
									* calResize.getRatioResizeHeight()), 0, 0);
					tmp.setLayoutParams(prView);
					tmp.setOnClickListener(this);
					packageSongs.get(countPackage).setImage(tmp);
					countPackage++;
					if (countPackage >= packageSongs.size()) {
						break;
					}
				}
			}
		}
	}

	/**
	 * This method used for set background of Vol1 songs.
	 * */
	private void setBackgroundForSingleV1_2Song() {

		if (modeDisplay == 1 && singleV1_2Songs.size() > 0) {
			int countPackage = 0;

			// browse to each page.
			for (int i = 0; i < totalPage; i++) {
				for (int j = 0; j < 6; j++) {

					// initial image.
					Bitmap bmImg = BitmapFactory.decodeFile(memory
							.getPathFileInternalMemory()
							+ "img_buy/"
							+ singleV1_2Songs.get(countPackage).getIconImage());
					Drawable d = new BitmapDrawable(bmImg);
					ImageView tmp = new ImageView(this);
					tmp.setBackgroundDrawable(d);
					if (isAppInstalled(memory.getPathFileExternalMemory()
							+ singleV1_2Songs.get(countPackage)
									.getPackageName(),
							singleV1_2Songs.get(countPackage).getPackageName())) {
						tmp.getBackground().setAlpha(100);
					}
					if (isAppRelationInstalled(singleV1_2Songs
							.get(countPackage).getPackageName(),
							singleV1_2Songs.get(countPackage)
									.getPackagesRelation())) {
						tmp.getBackground().setAlpha(100);
					}
					pageLayout[i].addView(tmp);
					tmp.setId(CONST_ID
							+ singleV1_2Songs.get(countPackage).getPackageID());
					RelativeLayout.LayoutParams prView = new RelativeLayout.LayoutParams(
							Math.round(317 * calResize.getRatioResizeWidth()),
							Math.round(166 * calResize.getRatioResizeHeight()));
					prView.setMargins(
							Math.round(coor[j][0]
									* calResize.getRatioResizeWidth()),
							Math.round(coor[j][1]
									* calResize.getRatioResizeHeight()), 0, 0);
					tmp.setLayoutParams(prView);
					tmp.setOnClickListener(this);
					singleV1_2Songs.get(countPackage).setImage(tmp);
					countPackage++;
					if (countPackage >= singleV1_2Songs.size()) {
						break;
					}
				}
			}
		}
	}

	/**
	 * This method used for set background of Vol1 songs.
	 * */
	private void setBackgroundForSingleV1Song() {

		if (modeDisplay == 1 && singleV1Songs.size() > 0) {
			int countPackage = 0;

			// browse to each page.
			for (int i = 0; i < totalPage; i++) {
				for (int j = 0; j < 6; j++) {

					// initial image.
					Bitmap bmImg = BitmapFactory.decodeFile(memory
							.getPathFileInternalMemory()
							+ "img_buy/"
							+ singleV1Songs.get(countPackage).getIconImage());
					Drawable d = new BitmapDrawable(bmImg);
					ImageView tmp = new ImageView(this);
					tmp.setBackgroundDrawable(d);
					if (isAppInstalled(memory.getPathFileExternalMemory()
							+ singleV1Songs.get(countPackage).getPackageName(),
							singleV1Songs.get(countPackage).getPackageName())) {
						tmp.getBackground().setAlpha(100);
					}
					if (isAppRelationInstalled(singleV1Songs.get(countPackage)
							.getPackageName(), singleV1Songs.get(countPackage)
							.getPackagesRelation())) {
						tmp.getBackground().setAlpha(100);
					}
					pageLayout[i].addView(tmp);
					tmp.setId(CONST_ID
							+ singleV1Songs.get(countPackage).getPackageID());
					RelativeLayout.LayoutParams prView = new RelativeLayout.LayoutParams(
							Math.round(317 * calResize.getRatioResizeWidth()),
							Math.round(166 * calResize.getRatioResizeHeight()));
					prView.setMargins(
							Math.round(coor[j][0]
									* calResize.getRatioResizeWidth()),
							Math.round(coor[j][1]
									* calResize.getRatioResizeHeight()), 0, 0);
					tmp.setLayoutParams(prView);
					tmp.setOnClickListener(this);
					singleV1Songs.get(countPackage).setImage(tmp);
					countPackage++;
					if (countPackage >= singleV1Songs.size()) {
						break;
					}
				}
			}
		}
	}

	/**
	 * This method used for set background of Vol2 songs.
	 * */
	private void setBackgroundForSingleV2Song() {

		if (modeDisplay == 1 && singleV2Songs.size() > 0) {
			int countPackage = 0;

			// browse to each page.
			for (int i = 0; i < totalPage; i++) {
				for (int j = 0; j < 6; j++) {

					// initial image.
					Bitmap bmImg = BitmapFactory.decodeFile(memory
							.getPathFileInternalMemory()
							+ "img_buy/"
							+ singleV2Songs.get(countPackage).getIconImage());
					Drawable d = new BitmapDrawable(bmImg);
					ImageView tmp = new ImageView(this);
					tmp.setBackgroundDrawable(d);
					if (isAppInstalled(memory.getPathFileExternalMemory()
							+ singleV2Songs.get(countPackage).getPackageName(),
							singleV2Songs.get(countPackage).getPackageName())) {
						tmp.getBackground().setAlpha(100);
					}
					if (isAppRelationInstalled(singleV2Songs.get(countPackage)
							.getPackageName(), singleV2Songs.get(countPackage)
							.getPackagesRelation())) {
						tmp.getBackground().setAlpha(100);
					}
					pageLayout[i].addView(tmp);
					tmp.setId(CONST_ID
							+ singleV2Songs.get(countPackage).getPackageID());
					RelativeLayout.LayoutParams prView = new RelativeLayout.LayoutParams(
							Math.round(317 * calResize.getRatioResizeWidth()),
							Math.round(166 * calResize.getRatioResizeHeight()));
					prView.setMargins(
							Math.round(coor[j][0]
									* calResize.getRatioResizeWidth()),
							Math.round(coor[j][1]
									* calResize.getRatioResizeHeight()), 0, 0);
					tmp.setLayoutParams(prView);
					tmp.setOnClickListener(this);
					singleV2Songs.get(countPackage).setImage(tmp);
					countPackage++;
					if (countPackage >= singleV2Songs.size()) {
						break;
					}
				}
			}
		}
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_CANNOT_CONNECT_ID:
			return createDialog(R.string.cannot_connect_title,
					R.string.cannot_connect_message);
		case DIALOG_BILLING_NOT_SUPPORTED_ID:
			return createDialog(R.string.billing_not_supported_title,
					R.string.billing_not_supported_message);
		default:
			return null;
		}
	}

	/**
	 * Replaces the language and/or country of the device into the given string.
	 * The pattern "%lang%" will be replaced by the device's language code and
	 * the pattern "%region%" will be replaced with the device's country code.
	 * 
	 * @param str
	 *            the string to replace the language/country within
	 * @return a string containing the local language and region codes
	 */
	private String replaceLanguageAndRegion(String str) {

		// Substitute language and or region if present in string
		if (str.contains("%lang%") || str.contains("%region%")) {
			Locale locale = Locale.getDefault();
			str = str.replace("%lang%", locale.getLanguage().toLowerCase());
			str = str.replace("%region%", locale.getCountry().toLowerCase());
		}
		return str;
	}

	/**
	 * This method used for create dialog by purpose.
	 * 
	 * @param titleId
	 *            ID of Title resource string.
	 * @param messageId
	 *            ID of message resource string.
	 * @return {@link Dialog} Dialog to show.
	 * */
	private Dialog createDialog(int titleId, int messageId) {
		String helpUrl = replaceLanguageAndRegion(getString(R.string.help_url));
		if (Consts.DEBUG) {
			Log.i(TAG, helpUrl);
		}
		final Uri helpUri = Uri.parse(helpUrl);

		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(titleId)
				.setIcon(android.R.drawable.stat_sys_warning)
				.setMessage(messageId)
				.setCancelable(false)
				.setPositiveButton(android.R.string.ok, null)
				.setNegativeButton(R.string.learn_more,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								Intent intent = new Intent(Intent.ACTION_VIEW,
										helpUri);
								startActivity(intent);
							}
						});
		return builder.create();
	}

	/**
	 * If the transactions has not been initialized, we send a
	 * RESTORE_TRANSACTIONS request to Android Market to get the list of
	 * purchased items for this user. This happens if the application has just
	 * been installed or the user wiped data. We do not want to do this on every
	 * startup, rather, we want to do only when the database needs to be
	 * initialized.
	 */
	private void restoreTransactions() {
		boolean initialized = prefs.getBoolean(FINISH_RESTORE, false);
		if (!initialized) {

			// if restore transaction then application in first run. We will not
			// allow download packages when restore success.
			isFirstRun = true;
			Log.d(TAG, "Start Restoring Transaction...");
			progressDialog = new ProgressDialog(Buy.this);
			progressDialog
					.setMessage(getString(R.string.restoring_transactions));
			progressDialog.show();
			mBillingService.restoreTransactions();
		} else {
			Log.d(TAG, "Transaction Already Restored.");
		}
	}

	/**
	 * This function allow enable buy button. Used when billing support or when
	 * user not purchased an item.
	 */
	private void enableWidgets() {
		if (Consts.DEBUG) {
			Log.d(TAG, "Enable Buy button.");
		}
		imgBuy.setEnabled(true);
	}

	/**
	 * This method used for detect status of song package. By purchase status
	 * and setup status to setup UI.
	 * 
	 * @param ps
	 *            {@link PackageSongs}Package to process.
	 * @return {@link Boolean} Result package installed or not.
	 * */
	private boolean processPackagePurchased(PackageSongs ps) {

		// Get purchase status.
		boolean isPurchased = false;
		boolean isPackRelationPurchased = false;

		// Set isFirstRun to False so user can Download after Buy
		isFirstRun = false;

		// Get package name for purchase.
		purchasedPackage = ps.getPackageName();
		purchasedImage = ps.getImage();
		Log.d("RELATION", ps.getPackagesRelation());

		mProgressCloseX.setImageResource(R.drawable.close_btn_adr4);
		mProgressCloseX.setEnabled(true);
		imgBack.setVisibility(View.GONE);
		Bitmap bmImg = BitmapFactory.decodeFile(memory
				.getPathFileInternalMemory() + "img_buy/" + ps.getImageInfo());
		imgInfo.setImageBitmap(bmImg);
		imgInfo.setOnTouchListener(this);

		// check package relation
		if (!(ps.getPackagesRelation().equalsIgnoreCase("") || ps
				.getPackagesRelation().equalsIgnoreCase(ps.getPackageName()))) {
			if (ps.getPackagesRelation().contains("#")) {
				String[] parseInfo = ps.getPackagesRelation().trim().split("#");
				for (int i = 0; i < parseInfo.length; i++) {
					if (Boolean.parseBoolean(prefs.getString(
							parseInfo[i],
							getResources().getBoolean(R.bool.debug_version)
									+ ";0").split(";")[0])) {
						isPackRelationPurchased = true;
						break;
					}
				}
			} else {
				isPackRelationPurchased = Boolean.parseBoolean(prefs.getString(
						ps.getPackagesRelation(),
						getResources().getBoolean(R.bool.debug_version) + ";0")
						.split(";")[0]);
			}
		}
		if (isPackRelationPurchased
				&& !getResources().getBoolean(R.bool.debug_version)) {
			imgOK.setVisibility(View.VISIBLE);
			imgCancelInfo.setImageResource(0);
			imgCancelInfo.setEnabled(false);
			imgBuy.setImageResource(0);
			imgBuy.setEnabled(false);
			if (ps.getPackageNumberSongs() == 1) {
				CommonUtils.popupAlert(Buy.this,
						getString(R.string.note_package_is_purchased));
			} else {
				CommonUtils.popupAlert(Buy.this,
						getString(R.string.note_single_is_purchased));
			}
			return false;
		}

		try {
			isPurchased = Boolean.parseBoolean(prefs.getString(
					purchasedPackage,
					getResources().getBoolean(R.bool.debug_version) + ";0")
					.split(";")[0]);
		} catch (Exception e) {
			isPurchased = false;
		}
		/**
		 * For test Direct Download (not needed to purchase), change the
		 * following line to: if (isPurchased) {
		 */
		if (!isPurchased && !checkFreeSongDownload(purchasedPackage)) {
			imgCancelInfo.setImageResource(R.drawable.cancel_iphone);
			imgCancelInfo.setVisibility(View.VISIBLE);
			imgCancelInfo.setEnabled(true);
			imgBuy.setImageResource(R.drawable.buy_iphone);
			enableWidgets();
			if (!isSDCardExisted || !prefs.getBoolean(BILLING_SUPPORT, false)) {

				// Disable buy button when no SDCARD or billing not supported.
				imgBuy.setAlpha(50);
				imgBuy.setEnabled(false);
			}
		} else {
			ReportHistory report = new ReportHistory(Buy.this);
			if (!isAppInstalled(memory.getPathFileExternalMemory()
					+ purchasedPackage, purchasedPackage) || report.getReportCountByPackage(purchasedPackage) > 0) {
				imgCancelInfo.setImageResource(R.drawable.cancel_iphone);
				imgCancelInfo.setEnabled(true);
				imgBuy.setImageResource(0);
				imgBuy.setEnabled(false);
				imgDownload.setVisibility(View.VISIBLE);
				if(checkFreeSongDownload(purchasedPackage)){
					imgDownload.setBackgroundResource(R.drawable.dl_bt_iphone);
				}else{
					imgDownload.setBackgroundResource(R.drawable.re_dl);
				}
				imgCancelInfo.setVisibility(View.VISIBLE);
			} else {
				imgOK.setVisibility(View.VISIBLE);
				if(purchasedPackage.contains("free.song.relation")){
					imgOK.setBackgroundResource(R.drawable.dlok_bt_iphone);
				}else{
					imgOK.setBackgroundResource(R.drawable.buy_ok);
				}
				imgCancelInfo.setImageResource(0);
				imgCancelInfo.setEnabled(false);
				imgBuy.setImageResource(0);
				imgBuy.setEnabled(false);
			}
		}
		return isPurchased;
	}

	/**
	 * Make a request purchase.
	 */
	public boolean requestPurchase(String id, String payload) {
		return mBillingService.requestPurchase(id, payload);
	}

	/**
	 * Called when this activity becomes visible.
	 */
	@Override
	protected void onStart() {
		Log.d(TAG, "onStart");
		super.onStart();
		ResponseHandler.register(mBillingObserver);
	}

	@Override
	public void onBackPressed() {
		if (!isTouch) {
			return;
		}
		if (modeDisplay != 0) {
			modeDisplay = 0;
			// recalculate number pages and recreate page.
			imgSlide.setBackgroundResource(R.drawable.sideber_cat_iphone);
			imgVol1.setBackgroundResource(0);
			imgVol2.setBackgroundResource(0);
			calculateTotalPage();
			createPages();
			setBackgroundForPackagesSong();
			realViewSwitcher.setCurrentScreen(0, false);
			imgVol1.setEnabled(false);
			imgVol2.setEnabled(false);
			imgSwitch.setBackgroundResource(R.anim.single_click_change);
			aniDrawSwitchSingle = (AnimationDrawable) imgSwitch.getBackground();
			aniDrawSwitchSingle.start();
		} else {
			if (dlPackage != null) {
				dlPackage.cancel(true);
			}
			if (spUnzip != null) {
				spUnzip.cancel(false);
			}
			releaseMemory();
			if (BACK_SCREEN.equalsIgnoreCase("")
					|| BACK_SCREEN.equalsIgnoreCase("Top")) {
				intent = new Intent(Buy.this, Top.class);
			} else {
				intent = new Intent(Buy.this, SelectSong.class);
			}
			BACK_SCREEN = "";
			startActivity(intent);
			finish();
			super.onBackPressed();
		}
	}

	@Override
	protected void onUserLeaveHint() {
		// Don't finish activity when purchase screen display.
	}

	@Override
	protected void onDestroy() {
		Log.d(TAG, "OnDestroy");
		super.onDestroy();
		if (purchasedPackage != null) {
			mBillingService.unbind();
		}
	}

	@Override
	public void releaseMemory() {
		if (page != null) {
			page.setText("");
			page = null;
		}
		if (pageLayout != null && pageLayout.length > 0) {
			clearAllPages();
		}
		if (imgOK != null) {
			setNullViewDrawable(imgOK);
		}
		if (imgCancelInfo != null) {
			setNullViewDrawable(imgCancelInfo);
		}
		if (mProgressCloseX != null) {
			setNullViewDrawable(mProgressCloseX);
		}
		if (imgBuy != null) {
			setNullViewDrawable(imgBuy);
		}
		if (imgDownload != null) {
			setNullViewDrawable(imgDownload);
		}
		if (imgInfo != null) {
			setNullViewDrawable(imgInfo);
		}
		if (imgSlide != null) {
			setNullViewDrawable(imgSlide);
		}
		if (imgSwitch != null) {
			setNullViewDrawable(imgSwitch);
		}
		if (imgVol1 != null) {
			setNullViewDrawable(imgVol1);
		}
		if (imgVol2 != null) {
			setNullViewDrawable(imgVol2);
		}
		if (mProgressDeer != null) {
			setNullViewDrawable(mProgressDeer);
		}
		if (mProgressBgr != null) {
			setNullViewDrawable(mProgressBgr);
		}
		if (mProgressKage != null) {
			setNullViewDrawable(mProgressKage);
		}
		if (mProgressBar != null) {
			setNullViewDrawable(mProgressBar);
		}
		if (mProgressText != null) {
			setNullViewDrawable(mProgressText);
		}
		imgDownload = null;
		rlBuy = null;
		imgCancelInfo = null;
		mProgressCloseX = null;
		imgOK = null;
		imgBuy = null;
		imgInfo = null;
		imgSlide = null;
		imgSwitch = null;
		imgVol1 = null;
		imgVol2 = null;

		intent = null;
		packagesList = null;
		packageSongs = null;
		singleV1Songs = null;
		singleV2Songs = null;
		pageLayout = null;
		realViewSwitcher = null;
		coor = null;
		aniDrawSwitchSingle = null;
		progressDialog = null;
		purchasedPackage = null;
		mBillingObserver = null;
		mHandler = null;
		mProgressDeer = null;
		mProgressBgr = null;
		mProgressKage = null;
		mProgressBar = null;
		mProgressText = null;
		super.releaseMemory();
	}

	private class DownloadSongPackage extends Download {

		@Override
		protected void onPreExecute() {
			isTouch = false;
			if (downloadBar == null) {
				downloadBar = (DownloadProgessBar) findViewById(R.id.download_bar);
				DownloadProgessBar.typeDataDownload = 1;
				resizeView(downloadBar, 163, 425, 0, 0);
			}
			downloadBar.setVisibility(View.VISIBLE);
			mProgressCloseX.setAlpha(100);
			imgCancelInfo.setVisibility(View.INVISIBLE);
			imgDownload.setVisibility(View.INVISIBLE);
			super.onPreExecute();
		}

		protected Boolean doInBackground(FilesModel... params) {
			FilesModel[] fm = new FilesModel[1];
			String pathFile = getString(R.string.url_package_download);
			if (isTablet()) {
				pathFile = getString(R.string.url_package_hd_download);
			}
			fm[0] = new FilesModel(purchasedPackage + ".zip", pathFile
					+ "download.php?package="+purchasedPackage,
					memory.getPathCacheExternalMemory());
			return super.doInBackground(fm[0]);
		}

		@Override
		public void onProgressUpdate(Integer... args) {
			if (args[0] != null) {
				downloadBar.updateProgessBar(args[0]);
			}
		}

		public DownloadSongPackage(Context context) {
			super(context, true);
		}

		@Override
		protected void onPostExecute(Boolean result) {
			if (result != null && result) {
				// unzip
				FilesModel[] fm = new FilesModel[1];
				fm[0] = new FilesModel(purchasedPackage + ".zip",
						memory.getPathCacheExternalMemory() + purchasedPackage
								+ ".zip", memory.getPathFileExternalMemory());
				DownloadProgessBar.STATUS_DOWNLOAD = getString(R.string.dlp_unzip);
				downloadBar.invalidate();
				spUnzip = (SongPackageUnzip) new SongPackageUnzip().execute(fm);
				// sent download info to statistic
				// Create a new HttpClient and Post Header
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost(
						getString(R.string.url_top_free_download)
								+ "download.php");
				try {
					// Add your data
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
							2);
					nameValuePairs.add(new BasicNameValuePair("device",
							Build.DEVICE));
					nameValuePairs.add(new BasicNameValuePair("product",
							Build.PRODUCT));
					nameValuePairs.add(new BasicNameValuePair("model",
							Build.MODEL));
					nameValuePairs.add(new BasicNameValuePair("manufacturer",
							Build.MANUFACTURER));
					nameValuePairs.add(new BasicNameValuePair("os_version",
							Build.VERSION.RELEASE));
					nameValuePairs.add(new BasicNameValuePair("device_id",
							Build.ID));
					nameValuePairs.add(new BasicNameValuePair("imei",
							CommonUtils.findDeviceID(Buy.this)));
					nameValuePairs.add(new BasicNameValuePair(
							"product_item_id", purchasedPackage));
					httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					Log.d("TEST", nameValuePairs.toString());

					// Send request
					httpclient.execute(httppost);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				downloadBar.setVisibility(View.GONE);
				downloadBar.reset();
				imgBuy.setImageResource(0);
				imgDownload.setVisibility(View.VISIBLE);
				imgCancelInfo.setVisibility(View.VISIBLE);
				isTouch = true;
			}
			super.onPostExecute(result);
		}
	}
	
	public boolean checkFreeSongDownload(String packageName){
		if(packageName.contains("free.song.relation")){
			return true;
		}
		return false;
	}

	private class SongPackageUnzip extends Unzip {
		@Override
		protected void onPostExecute(Boolean result) {
			if (result != null && result && imgOK != null) {
				imgBuy.setAlpha(255);
				imgCancelInfo.setAlpha(255);
				downloadBar.setVisibility(View.GONE);
				downloadBar.reset();
				// Disable buy button when finish buy and download.
				imgBuy.setImageResource(0);
				imgCancelInfo.setVisibility(View.GONE);
				imgDownload.setVisibility(View.GONE);
				Toast.makeText(Buy.this, getString(R.string.dlp_dl_completed),
						Toast.LENGTH_LONG).show();
				ReportHistory report = new ReportHistory(Buy.this);
				report.resetReportCountByPackage(purchasedPackage);
				if(purchasedPackage.contains("free.song.relation")){
					SharedPreferences.Editor edit = prefs.edit();
					edit.putString(purchasedPackage, "true;" + System.currentTimeMillis());
					edit.commit();
				}
				imgOK.postDelayed(new Runnable() {
					@Override
					public void run() {
						if (imgOK != null) {
							imgOK.setVisibility(View.VISIBLE);
							if(purchasedPackage.contains("free.song.relation")){
								imgOK.setBackgroundResource(R.drawable.dlok_bt_iphone);
							}else{
								imgOK.setBackgroundResource(R.drawable.buy_ok);
							}
							isTouch = true;
							isAllowDownload = false;
							mProgressCloseX.setAlpha(255);
							mProgressCloseX.setEnabled(true);
						}
					}
				}, 3000);
				purchasedImage.getBackground().setAlpha(100);
			} else {

			}
		}
	}

	public void parsePackageInfoXML() {
		/** Handling & parser XML . */
		if (new File(memory.getPathFileInternalMemory() + "img_buy/"
				+ "package_info.xml").exists()) {
			try {
				/** Handling XML . */
				SAXParserFactory spf = SAXParserFactory.newInstance();
				SAXParser sp = spf.newSAXParser();
				XMLReader xr = sp.getXMLReader();

				/** Create handler to handle XML Tags ( extends DefaultHandler ) */
				PackageXMLHandler packageXMLHandler = new PackageXMLHandler();
				xr.setContentHandler(packageXMLHandler);
				File packageInfo = new File(memory.getPathFileInternalMemory()
						+ "img_buy/" + "package_info.xml");
				InputStream inputStream = new FileInputStream(packageInfo);
				Reader reader = new InputStreamReader(inputStream, "UTF-8");
				xr.parse(new InputSource(reader));

				// get package list after parse XML.
				packagesList = PackageXMLHandler.pList;
				if (packagesList != null) {

					// initial package songs to manager list.
					PackageSongs.resetCountPackages();
					for (int i = 0; i < packagesList.getName().size(); i++) {
						switch (packagesList.getVol().get(i)) {
						case 1:
							singleV1Songs.add(new PackageSongs(packagesList
									.getId().get(i), packagesList
									.getSongNumber().get(i), packagesList
									.getName().get(i), packagesList
									.getChecksum().get(i), packagesList
									.getIcon().get(i), packagesList
									.getImageIntro().get(i), packagesList
									.getVol().get(i), packagesList
									.getPackageRelation().get(i)));
							break;
						case 2:
							singleV2Songs.add(new PackageSongs(packagesList
									.getId().get(i), packagesList
									.getSongNumber().get(i), packagesList
									.getName().get(i), packagesList
									.getChecksum().get(i), packagesList
									.getIcon().get(i), packagesList
									.getImageIntro().get(i), packagesList
									.getVol().get(i), packagesList
									.getPackageRelation().get(i)));
							break;
						case 3:
							packageSongs.add(new PackageSongs(packagesList
									.getId().get(i), packagesList
									.getSongNumber().get(i), packagesList
									.getName().get(i), packagesList
									.getChecksum().get(i), packagesList
									.getIcon().get(i), packagesList
									.getImageIntro().get(i), packagesList
									.getVol().get(i), packagesList
									.getPackageRelation().get(i)));
							break;
						}
					}
					singleV1_2Songs.addAll(singleV1Songs);
					singleV1_2Songs.addAll(singleV2Songs);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}