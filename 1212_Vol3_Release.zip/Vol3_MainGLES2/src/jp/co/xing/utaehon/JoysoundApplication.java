package jp.co.xing.utaehon;

import android.app.Application;
import android.util.Log;

public class JoysoundApplication extends Application {
	
	@Override
	public void onCreate() {
		Log.d("TEST", "JoysoundApplication");
		super.onCreate();
	}
}
