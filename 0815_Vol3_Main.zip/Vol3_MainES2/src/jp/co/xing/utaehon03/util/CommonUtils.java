package jp.co.xing.utaehon03.util;

import jp.co.xing.utaehon.R;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public final class CommonUtils {
	
	public static String findDeviceID(Context context) {
		String deviceID = android.provider.Settings.Secure.getString(
				context.getContentResolver(),
				android.provider.Settings.Secure.ANDROID_ID);
		return deviceID;
	}
	
	public static void popupAlert(Context context, String message) {
		final AlertDialog alertDialog = new AlertDialog.Builder(context).create();
		alertDialog.setMessage(message);
		alertDialog.setCancelable(false);
		alertDialog.setCanceledOnTouchOutside(false);
		alertDialog.setButton(context.getString(R.string.btn_yes),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						alertDialog.dismiss();
						return;
					}
				});
		alertDialog.show();
	}
}
