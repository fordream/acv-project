package com.xing.joy.others;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import jp.co.xing.utaehon.R;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import com.xing.joy.common.CoreActivity;
import com.xing.joy.common.DownloadProgessBar;
import com.xing.joy.common.HorizontalPager;
import com.xing.joy.common.HorizontalPager.OnScrollListener;
import com.xing.joy.common.PackageSongs;
import com.xing.joy.common.PackageXMLHandler;
import com.xing.joy.common.PackagesList;
import com.xing.joy.common.Songs;
import com.xing.joy.interfaces.IDataActions;
import com.xing.joy.processdata.Download;
import com.xing.joy.processdata.FilesModel;
import com.xing.joy.processdata.Unzip;

public class SelectSong extends CoreActivity implements OnTouchListener {

	private int totalPage = 0;
	private static int currentPage = 0;
	private static int currentTypeSort = 2;
	private HorizontalPager realViewSwitcher;
	private RelativeLayout[] pageLayout;
	private ArrayList<String> arrListPackages = new ArrayList<String>();
	private ImageView imgSlide, imgSortName, imgSortOld, imgSortNew, imgBuyBt;
	private AnimationDrawable draBuyBt;

	ArrayList<Songs> song = new ArrayList<Songs>();
	ArrayList<ImageView> imgSong = new ArrayList<ImageView>();

	int[] imgIdSlide = { R.drawable.haikei_karaoke_iphone,
			R.drawable.haikei_teasobi_iphone, R.drawable.haikei_uta_iphone };

	int[] imgIdBackground = { R.drawable.a1_18_iphone_karaoke_haikei,
			R.drawable.a1_18_iphone_douga_haikei,
			R.drawable.a1_18_iphone_uta_haikei };

	int[][] coorMovie = { { 250, 30 }, { 580, 30 }, { 250, 230 }, { 580, 230 },
			{ 250, 430 }, { 580, 430 } };

	int[][] coorSong = { { 260, 30 }, { 480, 30 }, { 700, 30 }, { 260, 230 },
			{ 480, 230 }, { 700, 230 }, { 260, 430 }, { 480, 430 },
			{ 700, 430 } };

	int iconsOnPage = 9;
	private TextView page;

	private RelativeLayout rlPager;
	private DownloadProgessBar downloadBar;
	private SongFreeDataDownload download;
	private AlertDialog alertDialog;

	/** Package list. */
	private PackagesList packagesList = null;

	/** List all packages that show in Buy Screen. */
	private HashMap<String, Boolean> packageSongs = new HashMap<String, Boolean>();

	public void onCreate(Bundle savedInstanceState) {

		// set isTouch
		isTouch = false;

		// config metric of application
		DisplayMetrics metric = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metric);
		metric.widthPixels = Math.round(metric.widthPixels
				* metric.scaledDensity);
		metric.heightPixels = Math.round(metric.heightPixels
				* metric.scaledDensity);

		Configuration config = new Configuration();
		getBaseContext().getResources().updateConfiguration(config, metric);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.select_song);
		createHemImage(R.id.select_display);

		if (appData.getStringData(IDataActions.TYPE_NAME).equalsIgnoreCase(
				"douga_clicked")) {
			iconsOnPage = 6;
		}
		try {
			listPackagesAndAddFreeSong();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		new GetPackageInfo().execute(arrListPackages
				.toArray(new String[arrListPackages.size()]));

		rlPager = (RelativeLayout) findViewById(R.id.relaytive_pager);
		resizeView(rlPager, 0, 0, 0, 0);

		imgSortName = (ImageView) findViewById(R.id.sort_name);
		resizeView(imgSortName, 16, 240, 0, 0);
		imgSortName.setOnTouchListener(this);

		imgSortOld = (ImageView) findViewById(R.id.sort_old);
		resizeView(imgSortOld, 16, 280, 0, 0);
		imgSortOld.setOnTouchListener(this);

		imgSortNew = (ImageView) findViewById(R.id.sort_new);
		resizeView(imgSortNew, 16, 320, 0, 0);
		imgSortNew.setOnTouchListener(this);

		setImageSort();

		imgBuyBt = (ImageView) findViewById(R.id.buy_bt);
		resizeView(imgBuyBt, 16, 380, 0, 0);
		imgBuyBt.setBackgroundResource(R.anim.selectsong_buy_bt);
		draBuyBt = (AnimationDrawable) imgBuyBt.getBackground();
		imgBuyBt.setOnTouchListener(this);

		imgSlide = (ImageView) findViewById(R.id.slider);
		resizeView(imgSlide, 0, 0, 0, 0);
		imgSlide.setBackgroundResource(imgIdSlide[appData
				.getIntData(IDataActions.TYPE_ID)]);

		// Create the view switcher
		realViewSwitcher = (HorizontalPager) findViewById(R.id.horizontal_pager);
		realViewSwitcher.addOnScrollListener(new OnScrollListener() {

			@Override
			public void onViewScrollFinished(int viewIndex) {
				currentPage = viewIndex;
				page.setText((currentPage + 1) + "/" + totalPage + " "
						+ getString(R.string.page));
			}

			@Override
			public void onScroll(int scrollX) {
			}
		});

		page = (TextView) findViewById(R.id.help_text);
		resizeView(page, 505, 600, 0, 0);

		Typeface font = Typeface.createFromFile(this.getFilesDir().toString()
				+ "/a_otf_jun501pro_bold.otf");
		page.setTextColor(Color.rgb(102, 51, 0));
		page.setTypeface(font);

	}

	private class GetPackageInfo extends AsyncTask<String, Integer, Long> {

		protected Long doInBackground(String... packages) {
			parsePackageInfoXML();
			for (String pack : packages) {
				getInforOfEachPackage(pack);
			}
			return (long) 0;
		}

		protected void onProgressUpdate(Integer... progress) {
		}

		protected void onPostExecute(Long result) {
			layoutPagesView();
			if (imgBack == null) {
				new Handler().postDelayed(new Runnable() {

					@Override
					public void run() {
						addBackButton(R.id.select_display);
						isTouch = true;
					}
				}, 1000);
			}
		}

		public void getInforOfEachPackage(String pack) {
			try {
				// check relation songs
				if (pack.contains("free.song.relation")) {
					if(!packageSongs.containsKey(pack)){
						return;
					}
				}
				// check songs bought
				if (!Boolean.parseBoolean(prefs.getString(pack,
						getResources().getBoolean(R.bool.debug_version) + ";0")
						.split(";")[0])) {
					return;
				}
				String path = memory.getPathFileExternalMemory() + pack
						+ ".ini";
				File txt = new File(path);
				BufferedReader br = new BufferedReader(new FileReader(txt));
				String line;
				while ((line = br.readLine()) != null) {
					String[] info = line.trim().split("#");
					Boolean checkSong = false;
					// new song
					if (info[4].trim().equalsIgnoreCase("NULL")
							&& appData.getStringData(IDataActions.TYPE_NAME)
									.equalsIgnoreCase("douga_clicked")) {
						continue;
					}
					if (song != null) {
						for (Iterator<Songs> iterator = song.iterator(); iterator
								.hasNext();) {
							Songs song = (Songs) iterator.next();
							if (song.getSongNameEnglish().equalsIgnoreCase(
									info[1].trim())) {
								checkSong = true;
							}
						}
					}
					if (!checkSong) {
						Songs tmp = new Songs(info[1].trim(), info[2].trim(),
								Integer.parseInt(info[0].trim()), pack,
								Long.parseLong(prefs.getString(
										pack,
										getResources().getBoolean(
												R.bool.debug_version)
												+ ";0").split(";")[1]),
								info[3].trim(), info[4].trim());
						song.add(tmp);
					}
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void layoutPagesView() {
		calculateTotalPage();
		createPages();
		if (currentPage >= totalPage) {
			currentPage = totalPage - 1;
		}
		if (song != null && song.size() > 0) {
			sortOrderSong(currentTypeSort);
			try {
				setBackgroundForPackagesSong();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void sortOrderSong(int type) {
		switch (type) {
		case 0:
			// sort name
			Collections.sort(song, Songs.SongNameComparator);
			realViewSwitcher.setCurrentScreen(currentPage, false);
			break;

		case 1:
			// sort date
			Songs.sortASC = true;
			Collections.sort(song);
			realViewSwitcher.setCurrentScreen(currentPage, false);
			break;

		case 2:
			// sort name
			Songs.sortASC = false;
			Collections.sort(song);
			realViewSwitcher.setCurrentScreen(currentPage, false);
			break;

		default:
			break;
		}
	}

	public void setBackgroundForPackagesSong() throws Exception {
		int countSong = 0;
		for (int i = 0; i < totalPage; i++) {
			for (int j = 0; j < iconsOnPage; j++) {
				ImageView iw = new ImageView(this);
				Drawable d;
				switch (appData.getIntData(IDataActions.TYPE_ID)) {
				case 0:
				case 2:
					// case for karaoke & uta
					String path1;
					if (song.get(countSong).getPackageName() != "") {
						path1 = memory.getPathFileExternalMemory()
								+ song.get(countSong).getPathImage()
								+ ".nomedia";
					} else {
						if (!checkSongIsDownloaded(song.get(countSong)
								.getSongNameEnglish(), song.get(countSong)
								.getPackageName())) {
							path1 = memory.getPathFileInternalMemory()
									+ song.get(countSong).getPathImage()
									+ "_before.png.nomedia";
						} else {
							path1 = memory.getPathFileInternalMemory()
									+ song.get(countSong).getPathImage()
									+ ".png.nomedia";
						}
					}
					InputStream in1 = null;
					try {
						File tmp = new File(path1);
						in1 = new FileInputStream(tmp);
						in1.read(tmp.getName().replace(".nomedia", "")
								.getBytes());
					} catch (final Exception e) {
						e.printStackTrace();
					}
					Bitmap bmImg = BitmapFactory.decodeStream(in1);
					d = new BitmapDrawable(bmImg);
					iw.setImageDrawable(d);
					RelativeLayout.LayoutParams prView1 = new RelativeLayout.LayoutParams(
							Math.round(200 * calResize.getRatioResizeWidth()),
							Math.round(166 * calResize.getRatioResizeHeight()));
					prView1.setMargins(
							Math.round(coorSong[j][0]
									* calResize.getRatioResizeWidth()),
							Math.round(coorSong[j][1]
									* calResize.getRatioResizeHeight()), 0, 0);
					iw.setLayoutParams(prView1);
					break;
				case 1:
					// case for movie
					String pathImgMovie;
					if (song.get(countSong).getPackageName() != "") {
						pathImgMovie = memory.getPathFileExternalMemory()
								+ song.get(countSong).getPathImageMovie()
								+ ".nomedia";
					} else {
						if (!checkSongIsDownloaded(song.get(countSong)
								.getSongNameEnglish(), song.get(countSong)
								.getPackageName())) {
							pathImgMovie = memory.getPathFileInternalMemory()
									+ song.get(countSong).getPathImageMovie()
									+ "_before.png.nomedia";
						} else {
							pathImgMovie = memory.getPathFileInternalMemory()
									+ song.get(countSong).getPathImageMovie()
									+ ".png.nomedia";
						}
					}
					InputStream in = null;
					try {
						File tmp = new File(pathImgMovie);
						in = new FileInputStream(tmp);
						in.read(tmp.getName().replace(".nomedia", "")
								.getBytes());
					} catch (final Exception e) {
						e.printStackTrace();
					}
					Bitmap bmImgMovie = BitmapFactory.decodeStream(in);
					d = new BitmapDrawable(bmImgMovie);
					iw.setImageDrawable(d);
					RelativeLayout.LayoutParams prView2 = new RelativeLayout.LayoutParams(
							Math.round(317 * calResize.getRatioResizeWidth()),
							Math.round(166 * calResize.getRatioResizeHeight()));
					prView2.setMargins(
							Math.round(coorMovie[j][0]
									* calResize.getRatioResizeWidth()),
							Math.round(coorMovie[j][1]
									* calResize.getRatioResizeHeight()), 0, 0);
					iw.setLayoutParams(prView2);
					break;
				}
				final int intSong = countSong;
				iw.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if (!isTouch) {
							return;
						}
						if (!checkSongIsDownloaded(song.get(intSong)
								.getSongNameEnglish(), song.get(intSong)
								.getPackageName())) {
							// DOWNLOAD
							FilesModel[] fm = new FilesModel[1];
							String pathFile = getString(R.string.url_song_free_download);
							if (isTablet()) {
								pathFile = getString(R.string.url_song_free_hd_download);
							}
							fm[0] = new FilesModel("song.zip", pathFile
									+ song.get(intSong).getSongNameEnglish()
											.toLowerCase() + ".zip", memory
									.getPathCacheExternalMemory());
							if (download == null) {
								download = (SongFreeDataDownload) new SongFreeDataDownload(
										SelectSong.this).execute(fm);
							}
						} else {
							// Save data
							appData.setStringData(IDataActions.PACKAGE_NAME,
									song.get(intSong).getPackageName());
							appData.setStringData(IDataActions.SONG_NAME, song
									.get(intSong).getSongNameEnglish());
							appData.setStringData(IDataActions.CLASS_NAME,
									"com.xing.joy.karaokes."
											+ song.get(intSong)
													.getSongNameEnglish());
							// Set intent
							Intent intent = new Intent(Intent.ACTION_DEFAULT);
							intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							if (appData.getIntData(IDataActions.TYPE_ID) == 1) {
								intent.setComponent(new ComponentName(
										getPackageName(),
										"com.xing.joy.play.PlayMovieDynamicGame"));
							} else {
								intent.setComponent(new ComponentName(
										getPackageName(),
										"com.xing.joy.play.DynamicSong"));
							}
							startActivity(intent);
							finish();
						}
					}
				});
				pageLayout[i].addView(iw);
				iw = null;
				countSong++;
				if (countSong >= song.size()) {
					break;
				}
			}
		}
		realViewSwitcher.setCurrentScreen(currentPage, false);
	}

	private class SongFreeDataDownload extends Download {

		@Override
		protected void onPreExecute() {
			isTouch = false;
			if (downloadBar == null) {
				downloadBar = (DownloadProgessBar) findViewById(R.id.download_bar);
				DownloadProgessBar.typeDataDownload = 0;
				resizeView(downloadBar, 163, 396, 0, 0);
			}
			downloadBar.setVisibility(View.VISIBLE);
			super.onPreExecute();
		}

		@Override
		public void onProgressUpdate(Integer... args) {
			if (args[0] != null) {
				downloadBar.updateProgessBar(args[0]);
			}
		}

		public SongFreeDataDownload(Context context) {
			super(context, true);
		}

		@Override
		protected void onPostExecute(Boolean result) {
			if (result != null && result) {
				// unzip
				FilesModel[] fm = new FilesModel[1];
				fm[0] = new FilesModel("song.zip",
						memory.getPathCacheExternalMemory() + "song.zip",
						memory.getPathFileInternalMemory());
				DownloadProgessBar.STATUS_DOWNLOAD = getString(R.string.dlp_unzip);
				downloadBar.invalidate();
				new SongFreeDataUnzip().execute(fm);
				download = null;
			} else {
				downloadBar.setVisibility(View.GONE);
				downloadBar.reset();
				download = null;
				isTouch = true;
			}
		}
	}

	private class SongFreeDataUnzip extends Unzip {
		@Override
		protected void onPostExecute(Boolean result) {
			try {
				isTouch = true;
				if (result != null && result) {
					for (int i = 0; i < pageLayout.length; i++) {
						pageLayout[i].removeAllViews();
						realViewSwitcher.removeView(pageLayout[i]);
					}
					createPages();
					setBackgroundForPackagesSong();
					downloadBar.setVisibility(View.GONE);
					downloadBar.reset();
					isTouch = true;
				} else {
					// unzip error
				}
			} catch (Exception e) {
			}
		}
	}

	public boolean checkSongIsDownloaded(String songName, String songPackage) {
		if (songPackage.equalsIgnoreCase("")) {
			return new File(memory.getPathFileInternalMemory()
					+ songName.toLowerCase() + "/" + songName.toLowerCase()
					+ ".jar").exists();
		} else {
			return new File(memory.getPathFileExternalMemory()
					+ songName.toLowerCase() + "/" + songName.toLowerCase()
					+ ".jar").exists();
		}

	}

	public void listPackagesAndAddFreeSong() throws NumberFormatException,
			IOException {
		// Get free song
		String path = memory.getPathFileInternalMemory() + "free.song.ini";
		File txt = new File(path);
		BufferedReader br = new BufferedReader(new FileReader(txt));
		String line;
		while ((line = br.readLine()) != null) {
			String[] info = line.split("#");
			if (info[4].equalsIgnoreCase("NULL")
					&& appData.getStringData(IDataActions.TYPE_NAME)
							.equalsIgnoreCase("douga_clicked")) {
				continue;
			}
			Songs tmp = new Songs(info[1], info[2], Integer.parseInt(info[0]),
					"", 1000000000000l, info[3], info[4]);
			song.add(tmp);
		}
		// Get package bought
		File dir = new File(memory.getPathFileExternalMemory());
		File[] filelist = dir.listFiles();
		if (filelist != null) {
			for (int i = 0; i < filelist.length; i++) {
				if (filelist[i].isFile()
						&& filelist[i].getName().endsWith(".ini")) {
					arrListPackages.add(filelist[i].getName().substring(0,
							filelist[i].getName().length() - 4));
				}
			}
		}
	}

	public String convertStreamToString(InputStream in) throws IOException {
		StringBuffer stream = new StringBuffer();
		byte[] b = new byte[4096];
		for (int n; (n = in.read(b)) != -1;) {
			stream.append(new String(b, 0, n));
		}
		return stream.toString();
	}

	public void calculateTotalPage() {
		if (song != null) {
			totalPage = song.size() / iconsOnPage;
			if (song.size() % iconsOnPage > 0) {
				totalPage += 1;
			}
			if (totalPage == 0) {
				totalPage = 1;
			}
		}
	}

	public void createPages() {
		pageLayout = new RelativeLayout[totalPage];

		// Create & set background for layout of each page.
		for (int i = 0; i < pageLayout.length; i++) {
			pageLayout[i] = new RelativeLayout(this);
			LayoutParams param = new LayoutParams(Math.round(960 * calResize
					.getRatioResizeWidth()), Math.round(640 * calResize
					.getRatioResizeHeight()));
			param.setMargins(Math.round(0 * calResize.getRatioResizeWidth()),
					Math.round(0 * calResize.getRatioResizeHeight()), 0, 0);
			pageLayout[i].setLayoutParams(param);
			realViewSwitcher.addView(pageLayout[i]);

			ImageView tmp = new ImageView(this);
			tmp.setLayoutParams(param);
			tmp.setBackgroundResource(imgIdBackground[appData
					.getIntData(IDataActions.TYPE_ID)]);
			pageLayout[i].addView(tmp);
			if (imgSong != null) {
				imgSong.add(tmp);
			}
			tmp = null;
		}
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		try {
			if (hasFocus) {
				if (draBuyBt != null) {
					draBuyBt.start();
				}
			}
		} catch (Exception e) {
		}
		super.onWindowFocusChanged(hasFocus);
		if (page != null) {
			int sizePage = page.getHeight() / 2;
			if (sizePage < 20) {
				sizePage = 20;
			}
			if (sizePage > 40) {
				sizePage = 40;
			}
			page.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePage);
		}
	}

	@Override
	public void onBackPressed() {
		if (imgBack != null && isTouch) {
			// currentPage = 0;
			// currentTypeSort = 2;
			releaseMemory();
			Intent intent = new Intent(SelectSong.this, Top.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			this.startActivity(intent);
			this.finish();
			super.onBackPressed();
		}
	}

	@Override
	protected void onUserLeaveHint() {
		// currentPage = 0;
		super.onUserLeaveHint();
	}

	@Override
	protected void onPause() {
		if (alertDialog != null) {
			alertDialog.dismiss();
			alertDialog = null;
		}
		System.gc();
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		if (download != null) {
			download.cancel(true);
			download = null;
		}
		super.onDestroy();
	}

	@Override
	public void releaseMemory() {
		super.releaseMemory();
		if (page != null) {
			page.setText("");
			page = null;
		}
		if (pageLayout != null && pageLayout.length > 0) {
			clearAllPages();
		}
		if (imgSlide != null) {
			setNullViewDrawable(imgSlide);
			imgSlide = null;
		}
		if (arrListPackages != null) {
			arrListPackages.clear();
			arrListPackages = null;
		}
		if (song != null) {
			song.clear();
			song = null;
		}
		if (imgSong != null) {
			for (Iterator<ImageView> getImg = imgSong.iterator(); getImg
					.hasNext();) {
				setNullViewDrawable((ImageView) getImg.next());
			}
			imgSong.clear();
			imgSong = null;
		}
		if (draBuyBt != null) {
			draBuyBt.stop();
			draBuyBt = null;
		}
		setNullViewDrawable(imgSortName);
		imgSortName = null;
		setNullViewDrawable(imgSortOld);
		imgSortOld = null;
		setNullViewDrawable(imgSortNew);
		imgSortNew = null;
		setNullViewDrawable(imgBuyBt);
		imgBuyBt = null;

	}

	public void clearAllPages() {
		for (int i = 0; i < pageLayout.length; i++) {
			pageLayout[i].removeAllViews();
			if (realViewSwitcher != null) {
				realViewSwitcher.removeView(pageLayout[i]);
			}
		}
		realViewSwitcher = null;
	}

	public void setImageSort() {
		switch (currentTypeSort) {
		case 0:
			imgSortName.setBackgroundResource(R.drawable.aiueo_on_iphone);
			imgSortNew.setBackgroundResource(R.drawable.new_off_iphone);
			imgSortOld.setBackgroundResource(R.drawable.old_off_iphone);
			break;
		case 1:
			imgSortName.setBackgroundResource(R.drawable.aiueo_off_iphone);
			imgSortNew.setBackgroundResource(R.drawable.new_off_iphone);
			imgSortOld.setBackgroundResource(R.drawable.old_on_iphone);
			break;
		case 2:
			imgSortName.setBackgroundResource(R.drawable.aiueo_off_iphone);
			imgSortNew.setBackgroundResource(R.drawable.new_on_iphone);
			imgSortOld.setBackgroundResource(R.drawable.old_off_iphone);
			break;
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN && pageLayout != null
				&& isTouch) {
			switch (v.getId()) {
			case R.id.sort_name:
				for (int i = 0; i < pageLayout.length; i++) {
					pageLayout[i].removeAllViews();
					realViewSwitcher.removeView(pageLayout[i]);
				}
				currentTypeSort = 0;
				currentPage = 0;
				sortOrderSong(currentTypeSort);
				setImageSort();
				createPages();
				try {
					setBackgroundForPackagesSong();
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case R.id.sort_old:
				for (int i = 0; i < pageLayout.length; i++) {
					pageLayout[i].removeAllViews();
					realViewSwitcher.removeView(pageLayout[i]);
				}
				currentTypeSort = 1;
				currentPage = 0;
				sortOrderSong(currentTypeSort);
				setImageSort();
				createPages();
				try {
					setBackgroundForPackagesSong();
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case R.id.sort_new:
				for (int i = 0; i < pageLayout.length; i++) {
					pageLayout[i].removeAllViews();
					realViewSwitcher.removeView(pageLayout[i]);
				}
				currentTypeSort = 2;
				currentPage = 0;
				sortOrderSong(currentTypeSort);
				setImageSort();
				createPages();
				try {
					setBackgroundForPackagesSong();
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case R.id.buy_bt:
				releaseMemory();
				Buy.BACK_SCREEN = "SelectSong";
				Intent intent = new Intent(SelectSong.this, Buy.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
				finish();
				break;

			default:
				break;
			}
		}
		return true;
	}

	public void parsePackageInfoXML() {
		/** Handling & parser XML . */
		if (new File(memory.getPathFileInternalMemory() + "img_buy/"
				+ "package_info.xml").exists()) {
			try {
				/** Handling XML . */
				SAXParserFactory spf = SAXParserFactory.newInstance();
				SAXParser sp = spf.newSAXParser();
				XMLReader xr = sp.getXMLReader();

				/** Create handler to handle XML Tags ( extends DefaultHandler ) */
				PackageXMLHandler packageXMLHandler = new PackageXMLHandler();
				xr.setContentHandler(packageXMLHandler);
				File packageInfo = new File(memory.getPathFileInternalMemory()
						+ "img_buy/" + "package_info.xml");
				InputStream inputStream = new FileInputStream(packageInfo);
				Reader reader = new InputStreamReader(inputStream, "UTF-8");
				xr.parse(new InputSource(reader));

				// get package list after parse XML.
				packagesList = PackageXMLHandler.pList;
				if (packagesList != null) {

					// initial package songs to manager list.
					PackageSongs.resetCountPackages();
					for (int i = 0; i < packagesList.getName().size(); i++) {
						packageSongs.put(packagesList.getName().get(i), true);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}