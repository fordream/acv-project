package jp.co.xing.utaehon03.resouces;

public interface TopResource {
	
	public interface top_background
	{
		public static final int TOP_00_IPHONE_TOP_BACK_ID = 0;
		public static final int TOP_18_IPHONE_JIMEN_ID = 1;
		public static final int TOP_20_1_IPHONE_LAKE_ID = 2;
		public static final int TOP_20_2_IPHONE_LAKE_ID = 3;
		public static final int TOP_21_IPHONE_OKA_ID = 4;
		public static final int TOP_22_IPHONE_HAIKEI_ID = 5;
	}
	
	public interface top_animation
	{
		public static final int TOP_02_IPHONE_KARAOKE_BTM_ID = 0;
		public static final int TOP_03_IPHONE_UTA_BT_ID = 1;
		public static final int TOP_04_ADR_CREDIT_BT_ID = 2;
		public static final int TOP_05_ADR_HELP_BT_ID = 3;
		public static final int TOP_06_1_IPHONE4_BEAR_ID = 4;
		public static final int TOP_06_2_IPHONE4_BEAR_ID = 5;
		public static final int TOP_06_3_IPHONE4_BEAR_ID = 6;
		public static final int TOP_07_1_IPHONE4_FOX_ID = 7;
		public static final int TOP_07_2_IPHONE4_FOX_ID = 8;
		public static final int TOP_09_1_IPHONE4_DEER_ID = 9;
		public static final int TOP_09_2_IPHONE4_DEER_ID = 10;
		public static final int TOP_10_IPHONE4_RABBIT_ID = 11;
		public static final int TOP_11_IPHONE_RIGHT_CROUD_ID = 12;
		public static final int TOP_12_IPHONE_LEFT_CROUD_ID = 13;
		public static final int TOP_13_IPHONE_LOGO_ID = 14;
		public static final int TOP_14_IPHONE_DOUGA_ID = 15;
		public static final int TOP_17_IPHONE_BUY_ID = 16;
		public static final int TOP_19_IPHONE_SWAN_ID = 17;
		public static final int TOP_19_IPHONE_SWAN_RIGHT_ID = 18;
	}
}
